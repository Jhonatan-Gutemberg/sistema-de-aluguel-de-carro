package Lab.CarRentalSystem.service.interfaces;

public interface IEmployerService {

}
