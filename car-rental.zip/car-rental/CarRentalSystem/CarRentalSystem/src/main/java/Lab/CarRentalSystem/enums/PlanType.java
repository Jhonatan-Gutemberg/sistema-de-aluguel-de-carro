package Lab.CarRentalSystem.enums;

public enum PlanType {
    DAILY,
    MONTHLY,
    BIANNUAL
}
