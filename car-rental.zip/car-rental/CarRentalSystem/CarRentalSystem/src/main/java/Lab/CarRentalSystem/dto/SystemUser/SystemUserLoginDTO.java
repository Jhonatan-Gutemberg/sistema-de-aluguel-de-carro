package Lab.CarRentalSystem.dto.SystemUser;

public record SystemUserLoginDTO(
                String name,
                String password) {

}
