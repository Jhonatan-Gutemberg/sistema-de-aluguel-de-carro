package Lab.CarRentalSystem.enums;

public enum SystemUserType {
    SYSTEMUSER,
    AGENCY,
    BANK,
    CUSTOMER
}
