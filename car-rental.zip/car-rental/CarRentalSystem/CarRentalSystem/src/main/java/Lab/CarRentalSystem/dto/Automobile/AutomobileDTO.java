package Lab.CarRentalSystem.dto.Automobile;

public record AutomobileDTO(

                String name,

                Double valuePerDay,

                int year,

                String registrationNumber,

                String brand,

                String model,

                String plate

) {
}
