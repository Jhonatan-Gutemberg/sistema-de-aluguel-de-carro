package Lab.CarRentalSystem.dto.Employment;

public record EmploymentDTO() {

}
