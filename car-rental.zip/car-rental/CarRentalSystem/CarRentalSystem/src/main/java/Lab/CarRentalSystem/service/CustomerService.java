package Lab.CarRentalSystem.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import Lab.CarRentalSystem.dto.Customer.CustomerDTO;
import Lab.CarRentalSystem.mappers.SystemUserMapper;
import Lab.CarRentalSystem.models.Customer;
import Lab.CarRentalSystem.repository.CustomerRepository;
import Lab.CarRentalSystem.repository.OrderRepository;
import Lab.CarRentalSystem.service.interfaces.ICustomerService;
import jakarta.persistence.criteria.Order;
import jakarta.transaction.Transactional;

@Service
@Transactional
public class CustomerService implements ICustomerService {

    @Autowired
    private CustomerRepository customerRepository;

    @Autowired
    private OrderRepository orderRepository;

    @Override
    public Customer register(CustomerDTO customerDTO) {
        Customer customer = SystemUserMapper.customerDtoToModel(customerDTO);
        customerRepository.save(customer);
        return customer;
    }

    @Override
    public List<Customer> getAllCustomers() {
        return customerRepository.findAll();
    }

    @Override
    public Customer getCustomerById(Long id) {
        Optional<Customer> customer = customerRepository.findById(id);
        return customer.orElse(null);
    }

    @Override
    public Customer updateCustomer(Long id, CustomerDTO customerDTO) {
        Optional<Customer> optionalCustomer = customerRepository.findById(id);
        if (optionalCustomer.isPresent()) {
            Customer existingCustomer = optionalCustomer.get();
            existingCustomer.setName(customerDTO.name());
            existingCustomer.setAddress(customerDTO.address());
            existingCustomer.setRegistration(customerDTO.registration());
            existingCustomer.setCpf(customerDTO.cpf());

            customerRepository.save(existingCustomer);
            return existingCustomer;
        } else {
            return null;
        }
    }

    @Override
    public boolean deleteCustomer(Long id) {
        Optional<Customer> optionalCustomer = customerRepository.findById(id);
        if (optionalCustomer.isPresent()) {
            customerRepository.delete(optionalCustomer.get());
            return true;
        } else {
            return false;
        }

    }

    @Override
    public boolean processPayment(Long customerId, Long orderId) {
        // Encontre o cliente
        Customer customer = customerRepository.findById(customerId)
                .orElseThrow(() -> new RuntimeException("Cliente não encontrado"));

        // Encontre a ordem usando a classe totalmente qualificada se necessário
        Lab.CarRentalSystem.models.Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new RuntimeException("Ordem não encontrada"));

        // Verifique se o cliente tem saldo suficiente
        if (customer.getBalance() >= order.getValue()) {
            // Deduzir o valor do saldo do cliente
            customer.setBalance(customer.getBalance() - order.getValue());
            customerRepository.save(customer); // Salva o cliente com o novo saldo

            return true;
        } else {
            return false; // Saldo insuficiente
        }
    }

}
