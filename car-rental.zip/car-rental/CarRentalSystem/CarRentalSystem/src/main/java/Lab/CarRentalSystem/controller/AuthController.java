package Lab.CarRentalSystem.controller;

public class AuthController {
    
}
